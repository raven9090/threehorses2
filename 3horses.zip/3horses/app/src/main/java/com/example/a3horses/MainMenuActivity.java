package com.example.a3horses;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainMenuActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String PREFS_NAME = "MyPrefsFile";
    private static final String SCORE_KEY = "score";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        Button start = findViewById(R.id.opros);
        start.setOnClickListener(this);
        Button aboutus = findViewById(R.id.aboutus);
        aboutus.setOnClickListener(this::onClick2);
        Button settings = findViewById(R.id.settings);
        settings.setOnClickListener(this::onClick3);
        Button leader = findViewById(R.id.leader);
        leader.setOnClickListener(this::onClick4);

        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int totalScore = sharedPreferences.getInt(SCORE_KEY, 0);

        TextView pointsTextView = findViewById(R.id.Points);
        if (pointsTextView != null) {
            pointsTextView.setText("Очки: (" + totalScore + ")");
        } else {
        }
    }

    @Override
    public void onClick(View v) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int totalScore = sharedPreferences.getInt(SCORE_KEY, 0);
        Leaderboard.saveLeaderboardScore(this, "user", totalScore);

        Intent i = new Intent(this, oprosask.class);
        startActivity(i);
    }

    public void onClick2(View v) {
        Intent i = new Intent(this, AboutUs.class);
        startActivity(i);
    }

    public void onClick3(View v) {
        Intent i = new Intent(this, ChatActivity.class);
        startActivity(i);
    }

    public void onClick4(View v) {
        Intent i = new Intent(this, Leaderboard.class);
        startActivity(i);
    }
}