package com.example.a3horses;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log; // Import Log
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class SignUp extends AppCompatActivity implements View.OnClickListener {

    private EditText SignUp_email, SignUp_password, SignUp_nickname;
    private Button SignUp_btn;
    private FirebaseAuth mAuth;
    private static final String TAG = "SignUpActivity"; // Add TAG

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        Button back = (Button) findViewById(R.id.signupback);
        back.setOnClickListener(this);

        mAuth = FirebaseAuth.getInstance();

        SignUp_email = findViewById(R.id.signemailtext);
        SignUp_password = findViewById(R.id.signpasswordtext);
        SignUp_nickname = findViewById(R.id.nicknametext);
        SignUp_btn = findViewById(R.id.SignIn);

        findViewById(R.id.SignIn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String email = SignUp_email.getText().toString();
                final String password = SignUp_password.getText().toString();
                String nickname = SignUp_nickname.getText().toString();

                if (email.isEmpty() || password.isEmpty() || nickname.isEmpty()) {
                    Toast.makeText(SignUp.this, "Не все поля заполнены", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.length() < 6) {
                    Toast.makeText(SignUp.this,
                            "Пароль должен составлять не менее 6 символов",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Log.d(TAG, "createUserWithEmail:success");
                                    Toast.makeText(SignUp.this, "Готово!", Toast.LENGTH_SHORT).show();
                                    goNext();
                                } else {
                                    // Log the exception message
                                    Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                    Toast.makeText(SignUp.this, "Ошибка регистрации: " + task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    public void onClick(View view) {
        Intent i;
        i = new Intent(this, MainActivity1.class);
        startActivity(i);
    }

    private void goNext() {
        Intent intent = new Intent(SignUp.this, MainActivity0.class);
        startActivity(intent);
        finish();
    }
}