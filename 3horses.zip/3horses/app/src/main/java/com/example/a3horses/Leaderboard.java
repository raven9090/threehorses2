package com.example.a3horses;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Leaderboard extends AppCompatActivity {

    private static final String PREFS_NAME = "LeaderboardPrefs";
    private static final int MAX_LEADERS = 10;

    private TextView top1, top2, top3, top4, top5, top6, top7, top8, top9, top10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        top1 = findViewById(R.id.top1);
        top2 = findViewById(R.id.top2);
        top3 = findViewById(R.id.top3);
        top4 = findViewById(R.id.top4);
        top5 = findViewById(R.id.top5);
        top6 = findViewById(R.id.top6);
        top7 = findViewById(R.id.top7);
        top8 = findViewById(R.id.top8);
        top9 = findViewById(R.id.top9);
        top10 = findViewById(R.id.top10);

        displayLeaderboard();
    }

    private void displayLeaderboard() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Map<String, ?> allEntries = sharedPreferences.getAll();

        List<Map.Entry<String, ?>> sortedList = new ArrayList<>(allEntries.entrySet());
        Collections.sort(sortedList, new Comparator<Map.Entry<String, ?>>() {
            @Override
            public int compare(Map.Entry<String, ?> o1, Map.Entry<String, ?> o2) {
                return Integer.compare((Integer) o2.getValue(), (Integer) o1.getValue());
            }
        });

        TextView[] topTextViews = {top1, top2, top3, top4, top5, top6, top7, top8, top9, top10};

        for (int i = 0; i < Math.min(MAX_LEADERS, sortedList.size()); i++) {
            String username = sortedList.get(i).getKey();
            int score = (Integer) sortedList.get(i).getValue();
            topTextViews[i].setText((i + 1) + ". " + username + ": " + score);
        }

        // Clear remaining TextViews if fewer than 10 leaders
        for (int i = sortedList.size(); i < MAX_LEADERS; i++) {
            topTextViews[i].setText((i + 1) + ". "); // Clear text views
        }
    }

    // Method to save a user's score in the leaderboard
    public static void saveLeaderboardScore(Context context, String username, int score) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Check if the user already has a score
        int existingScore = sharedPreferences.getInt(username, 0);

        // Update score only if the new score is higher
        if (score > existingScore) {
            editor.putInt(username, score);
            editor.apply();
        }
    }
}