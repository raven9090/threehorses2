package com.example.a3horses;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import android.widget.TextView;
public class ChatActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText inputMessage;
    private ImageButton buttonSend;
    private DatabaseReference messagesRef;
    private FirebaseRecyclerAdapter<ChatMessage, MessageViewHolder> adapter;
    private String currentUserName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        // Получаем текущего пользователя
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            //Здесь можно получать логин из профиля, если он там сохранен, или использовать email как логин
            currentUserName = currentUser.getEmail();  // Или другой способ получения логина
        } else {
            currentUserName = "Аноним"; // Если пользователь не вошел
        }

        inputMessage = findViewById(R.id.inputMessage);
        buttonSend = findViewById(R.id.buttonSend);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Получаем ссылку на базу данных Firebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        messagesRef = database.getReference("messages");

        buttonSend.setOnClickListener(view -> {
            String messageText = inputMessage.getText().toString().trim();
            if (!messageText.isEmpty()) {
                // Создаем объект сообщения
                ChatMessage message = new ChatMessage(messageText, currentUserName);
                // Отправляем сообщение в Firebase
                messagesRef.push().setValue(message);
                // Очищаем поле ввода
                inputMessage.setText("");
            }
        });

        // Настраиваем FirebaseRecyclerAdapter
        Query query = messagesRef.orderByKey().limitToLast(50);  // Показываем последние 50 сообщений
        FirebaseRecyclerOptions<ChatMessage> options =
                new FirebaseRecyclerOptions.Builder<ChatMessage>()
                        .setQuery(query, ChatMessage.class)
                        .build();

        adapter = new FirebaseRecyclerAdapter<ChatMessage, MessageViewHolder>(options) {
            @Override
            public MessageViewHolder onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
                android.view.View view = android.view.LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.message_item, parent, false);
                return new MessageViewHolder(view);
            }

            @Override
            protected void onBindViewHolder(MessageViewHolder holder, int position, ChatMessage model) {
                holder.messageText.setText(model.getMessageText());
                holder.messageUser.setText(model.getMessageUser()); // Отображаем логин
            }
        };

        recyclerView.setAdapter(adapter);
        adapter.startListening(); // Начинаем прослушивание изменений в базе данных

        // Прокручиваем RecyclerView в самый низ при добавлении нового сообщения
        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);
                int messageCount = adapter.getItemCount();
                int lastVisiblePosition = ((LinearLayoutManager) recyclerView.getLayoutManager()).findLastCompletelyVisibleItemPosition();
                // Если это добавление нового сообщения и пользователь видит последнее сообщение, прокручиваем список
                if (lastVisiblePosition == -1 || (positionStart >= (messageCount - 1) && lastVisiblePosition == (positionStart -1))) {
                    recyclerView.scrollToPosition(positionStart);
                }
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (adapter != null) {
            adapter.startListening();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (adapter != null) {
            adapter.stopListening();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (adapter != null) {
            adapter.stopListening();
        }
    }

    // ViewHolder для отображения сообщения
    public static class MessageViewHolder extends RecyclerView.ViewHolder {
        TextView messageText;
        TextView messageUser;

        MessageViewHolder(android.view.View itemView) {
            super(itemView);
            messageText = itemView.findViewById(R.id.message_text);
            messageUser = itemView.findViewById(R.id.message_user);
        }
    }
}