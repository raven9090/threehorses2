package com.example.a3horses;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class oprosask extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oprosask);
        Button start = (Button) findViewById(R.id.startopros);
        start.setOnClickListener(this);
        Button back = (Button) findViewById(R.id.oprosasklater);
        back.setOnClickListener(this::onClick2);
    }


    @Override
    public void onClick(View v) {
        Intent i;
        i = new Intent(this, question1.class);
        startActivity(i);

    }
    public void onClick2(View v) {
        Intent i;
        i = new Intent(this, MainMenuActivity.class);
        startActivity(i);

    }
}