package com.example.a3horses;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class question3 extends AppCompatActivity implements View.OnClickListener {

    private static final String PREFS_NAME = "MyPrefsFile";
    private static final String SCORE_KEY = "score";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question3);

        Button answer1 = findViewById(R.id.answer1);
        answer1.setOnClickListener(this);
        Button answer2 = findViewById(R.id.answer2);
        answer2.setOnClickListener(this::onClick2);
        Button answer3 = findViewById(R.id.answer3);
        answer3.setOnClickListener(this::onClick3);
        Button answer4 = findViewById(R.id.answer4);
        answer4.setOnClickListener(this::onClick4);
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(this, question3success.class);
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int currentScore = sharedPreferences.getInt(SCORE_KEY, 0);
        int newScore = currentScore + 5;
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(SCORE_KEY, newScore);
        editor.apply();
        i.putExtra("score", newScore);
        startActivity(i);
    }

    public void onClick2(View v) {
        Intent ii = new Intent(this, question3fail.class);
        startActivity(ii);
    }

    public void onClick3(View v) {
        Intent ii = new Intent(this, question3fail.class);
        startActivity(ii);

    }

    public void onClick4(View v) {
        Intent ii = new Intent(this, question3fail.class);
        startActivity(ii);
    }
}