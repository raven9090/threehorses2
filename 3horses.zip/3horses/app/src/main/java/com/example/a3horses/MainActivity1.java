package com.example.a3horses;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity1 extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        Button signup = (Button) findViewById(R.id.signupbutton);
        signup.setOnClickListener(this);
        Button login = (Button) findViewById(R.id.loginbutton);
        login.setOnClickListener(this::onClick2);
    }


    @Override
    public void onClick(View v) {
        Intent i;
        i = new Intent(this, SignUp.class);
        startActivity(i);
    }


    public void onClick2(View v) {
        Intent ii;
        ii = new Intent(this, LogInActivity2.class);
        startActivity(ii);
    }
}
