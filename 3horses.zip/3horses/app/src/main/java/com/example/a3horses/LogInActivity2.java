package com.example.a3horses;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;  // Import Log
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import androidx.annotation.NonNull;

public class LogInActivity2 extends AppCompatActivity implements View.OnClickListener {
    private EditText LogIn_email, LogIn_password;
    private Button LogIn_btn;
    private FirebaseAuth mAuth;
    private static final String TAG = "LoginActivity2"; // Add TAG

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in2);
        Button back = (Button) findViewById(R.id.loginbackbutton2);
        back.setOnClickListener(this);
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            goNext();
        }

        LogIn_email = findViewById(R.id.LogIn_email);
        LogIn_password = findViewById(R.id.LogIn_password);
        LogIn_btn = findViewById(R.id.LogIn_btn);
        LogIn_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = LogIn_email.getText().toString();
                final String password = LogIn_password.getText().toString();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LogInActivity2.this, "Не все поля заполнены", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.length() < 6) {
                    Toast.makeText(LogInActivity2.this, "Пароль должен составлять не менее 6 символов", Toast.LENGTH_SHORT).show();
                    return;
                }
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d(TAG, "signInWithEmail:success");
                                    Toast.makeText(LogInActivity2.this, "Готово.",
                                            Toast.LENGTH_SHORT).show();
                                    goNext();
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w(TAG, "signInWithEmail:failure", task.getException());
                                    Toast.makeText(LogInActivity2.this, "Ошибка входа: " + task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    public void onClick(View view) {
        Intent i;
        i = new Intent(this, MainActivity1.class);
        startActivity(i);
    }

    public void goNext() {
        startActivity(new Intent(LogInActivity2.this, MainMenuActivity.class));
        finish();
    }
}