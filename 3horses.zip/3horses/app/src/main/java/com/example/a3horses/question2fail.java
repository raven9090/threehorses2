package com.example.a3horses;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class question2fail extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question2fail);
        Button back = (Button) findViewById(R.id.nextquestionbuttonfail);
        back.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        Intent i;
        i = new Intent(this, question3.class);
        startActivity(i);
    }
}