package com.example.a3horses;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity0 extends AppCompatActivity {
    private final int zagr = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent peremenay = new Intent(MainActivity0.this, MainActivity1.class);
                MainActivity0.this.startActivity(peremenay);
                MainActivity0.this.finish();
            }
        }, zagr);
    }
}